package com.doozen.jks.exviewswitcher;

public class WordData {
    public String EnglishWord;
    public String KoreanWord;
    public String Examples;

    public String getEnglishWord() {
        return EnglishWord;
    }

    public void setEnglishWord(String englishWord) {
        EnglishWord = englishWord;
    }

    public String getKoreanWord() {
        return KoreanWord;
    }

    public void setKoreanWord(String koreanWord) {
        KoreanWord = koreanWord;
    }

    public String getExamples() {
        return Examples;
    }

    public void setExamples(String examples) {
        Examples = examples;
    }
}
