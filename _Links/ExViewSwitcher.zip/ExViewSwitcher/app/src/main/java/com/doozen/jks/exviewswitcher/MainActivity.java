package com.doozen.jks.exviewswitcher;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ViewSwitcher;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ViewSwitcher viewSwitcher;
    private int wordIndex;
    private Button topButton;
    private TextView txtQuestion1, txtQuestion2;
    private Button btnAnswer11, btnAnswer12, btnAnswer13, btnAnswer14, btnAnswer15;
    private Button btnAnswer21, btnAnswer22, btnAnswer23, btnAnswer24, btnAnswer25;
    private boolean isFirst;
    private ArrayList<WordData> wordArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wordArray = new ArrayList<>();
        initWordArray();

        wordIndex = 0;
        isFirst = true;

        initTextViews();

        displayQuestion();

        Button buttonNext = findViewById(R.id.btnNext);
        Button buttonPrevious = findViewById(R.id.btnPrev);
        viewSwitcher = findViewById(R.id.switcher);

        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wordIndex++;
                if (wordIndex >= wordArray.size()) { wordIndex = 0; }

                displayQuestion();

                viewSwitcher.showNext();
            }
        });

        buttonPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wordIndex--;
                if (wordIndex < 0) { wordIndex = wordArray.size()-1; }

                displayQuestion();

                viewSwitcher.showPrevious();
            }
        });
    }

    private void initWordArray() {
        for(int i=0; i<10; i++) {
            WordData wd = new WordData();
            wd.EnglishWord = String.format("English %d", i+1);
            wd.KoreanWord = String.format("Korean %d", i+1);
            wd.Examples = String.format("ex%d_1,ex%d_2,ex%d_3,ex%d_4,ex%d_5", i+1,i+1,i+1,i+1,i+1);
            wordArray.add(wd);
        }
    }

    private void initTextViews() {
        topButton = findViewById(R.id.topButton);

        txtQuestion1 = findViewById(R.id.questionWord1);
        btnAnswer11 = findViewById(R.id.answerWord11);
        btnAnswer12 = findViewById(R.id.answerWord12);
        btnAnswer13 = findViewById(R.id.answerWord13);
        btnAnswer14 = findViewById(R.id.answerWord14);
        btnAnswer15 = findViewById(R.id.answerWord15);

        txtQuestion2 = findViewById(R.id.questionWord2);
        btnAnswer21 = findViewById(R.id.answerWord21);
        btnAnswer22 = findViewById(R.id.answerWord22);
        btnAnswer23 = findViewById(R.id.answerWord23);
        btnAnswer24 = findViewById(R.id.answerWord24);
        btnAnswer25 = findViewById(R.id.answerWord25);
    }

    private void displayQuestion() {
        WordData wd = wordArray.get(wordIndex);
        String [] exValues = wd.Examples.split(",");

        int nRightAnswer = 0;
        boolean isSet = false;
        String [] strAnswers = new String[5];

        int [] nOrders = getWordOrder();
        for (int j=0; j<nOrders.length; j++) {

            if (nOrders[j]==0) {
                strAnswers[j] = wd.KoreanWord;
                nRightAnswer = j+1;
                isSet = true;
            }
            else {
                strAnswers[j] = exValues[nOrders[j]];
            }

            Log.d("TEST", "i: " + j + " --> " + nOrders[j]);
        }

        if (isSet==false) {
            strAnswers[3] = wd.KoreanWord;
        }
        strAnswers[4] = "모르겠음";


        if (isFirst) {
            txtQuestion1.setText(wd.EnglishWord);
            btnAnswer11.setText(strAnswers[0]);
            btnAnswer12.setText(strAnswers[1]);
            btnAnswer13.setText(strAnswers[2]);
            btnAnswer14.setText(strAnswers[3]);
            btnAnswer15.setText(strAnswers[4]);
        }
        else {
            txtQuestion2.setText(wd.EnglishWord);
            btnAnswer21.setText(strAnswers[0]);
            btnAnswer22.setText(strAnswers[1]);
            btnAnswer23.setText(strAnswers[2]);
            btnAnswer24.setText(strAnswers[3]);
            btnAnswer25.setText(strAnswers[4]);
        }

        topButton.setText(String.format("%d / %d", wordIndex+1, wordArray.size()));

        isFirst = !isFirst;
    }

    private int[] getWordOrder() {
        int [] nOrders = new int[4];
        int nIdx = 0;

        while(nIdx<4){
            int random = new Random().nextInt(5);
            boolean isExist = false;
            for (int i=0; i<nIdx; i++) {
                if (random == nOrders[i]) {
                    isExist = true;
                    break;
                }
            }
            if (isExist==false){
                nOrders[nIdx] = random;
                nIdx++;
            }
        }
        return nOrders;
    }

}
