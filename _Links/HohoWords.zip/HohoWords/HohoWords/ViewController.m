//
//  ViewController.m
//  HohoWords
//
//  Created by lucid on 29/04/2019.
//  Copyright © 2019 lucid. All rights reserved.
//

#import "ViewController.h"
#import "RangeViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)btnHyunhoClicked:(id)sender {
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    RangeViewController *vc = [sb instantiateViewControllerWithIdentifier:@"RangeVC"];
    [self.navigationController pushViewController:vc animated:YES];
    
//    vc.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
//    [self presentViewController:vc animated:YES completion:NULL];
}

- (IBAction)btnYoonhoClicked:(id)sender {
    
}

@end
