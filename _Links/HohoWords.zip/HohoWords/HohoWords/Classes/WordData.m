//
//  WordData.m
//  HohoWords
//
//  Created by lucid on 29/04/2019.
//  Copyright © 2019 lucid. All rights reserved.
//

#import "WordData.h"

@implementation WordData

@end
