//
//  WordData.h
//  HohoWords
//
//  Created by lucid on 29/04/2019.
//  Copyright © 2019 lucid. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface WordData : NSObject

@property (nonatomic, assign)   NSInteger   WordNumber;     //word 번호
@property (nonatomic, retain)   NSString    *EnglishWord;   //영어 단어
@property (nonatomic, retain)   NSString    *KoreanWord;    //한글 뜻
@property (nonatomic, retain)   NSString    *Examples;      //보기

@end


@interface QuestionInfo : NSObject

@property (nonatomic, retain)   NSString    *rightAnswer;     //정답 번호
@property (nonatomic, retain)   NSString    *applyAnswer;     //제출 번호
@property (nonatomic, retain)   WordData    *wordData;        //해당 단어

@end

@interface ExamResult : NSObject

@property (nonatomic, retain)   NSString    *testerName;    //수험자
@property (nonatomic, retain)   NSString    *testDate;      //일자
@property (nonatomic, retain)   NSString    *WrongWords;    //틀린 단어

@end





NS_ASSUME_NONNULL_END
