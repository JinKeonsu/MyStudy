//
//  TestViewController.m
//  HohoWords
//
//  Created by lucid on 29/04/2019.
//  Copyright © 2019 lucid. All rights reserved.
//

#import "TestViewController.h"
#import "WordDataManager.h"
#import "WordData.h"

@interface TestViewController ()
@property (weak, nonatomic) IBOutlet UIView *guideView;
@property (weak, nonatomic) IBOutlet UIView *mainView;

@end

@implementation TestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    questionArray = [[NSMutableArray alloc]init];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)makeQuestions {
    [questionArray removeAllObjects];
    currentNumber = 0;
    
    NSArray *wordArray = [WordDataManager getWordArray:self.nYear range:NSMakeRange(self.startNumber, (self.endNumber-self.startNumber)) count:self.questionCount];
    
    for (int i=0; i<[wordArray count]; i++) {
        QuestionInfo *qi = [[QuestionInfo alloc]init];
        qi.rightAnswer = [NSString stringWithFormat:@"%d", [self getRandomRightNumber]];
        qi.applyAnswer = @"";
        qi.wordData = (WordData*)[wordArray objectAtIndex:i];
        
        [questionArray addObject:qi];
    }
    
}

- (int)getRandomRightNumber {
    int randomNumber = arc4random() % 5 + 1;
    return randomNumber;
}

- (void)displayQuestion:(int)nIndex {
    
}
- (IBAction)startButtonClicked:(id)sender {
}
- (IBAction)prevButtonClicked:(id)sender {
}
- (IBAction)nextButtonClicked:(id)sender {
}

@end
