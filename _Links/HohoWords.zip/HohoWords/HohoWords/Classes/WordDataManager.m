//
//  WordDataManager.m
//  HohoWords
//
//  Created by lucid on 29/04/2019.
//  Copyright © 2019 lucid. All rights reserved.
//

#import "WordDataManager.h"
#import "WordData.h"


@implementation WordDataManager


//- (id)initManager {
//    self = [super init];
//    if (self)
//    {
//        [self loadWordData];
//    }
//
//    return self;
//}
//
//- (void)loadWordData {
//}

//- (NSDictionary *)JSONFromFile:(int)year {
//    NSString *strName = [NSString stringWithFormat:@"words_year%d", year];
//    NSString *path = [[NSBundle mainBundle] pathForResource:strName ofType:@"json"];
//    NSData *data = [NSData dataWithContentsOfFile:path];
//    return [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
//}

+ (NSArray*)getWordArray:(int)year range:(NSRange)range count:(int)count{
    
    srand([[NSDate date] timeIntervalSince1970]);
    
    NSMutableArray *numberArray = [NSMutableArray array];
    NSInteger firstValue = range.location;
    NSInteger rangeValue = range.length;
    
    for (int i=0; i<count; i++) {
        while(1) {
            int randomNumber = arc4random() % rangeValue;
            NSString *strKey = [NSString stringWithFormat:@"%04ld", (firstValue+randomNumber)];
            if ([numberArray containsObject:strKey]==NO) {
                [numberArray addObject:strKey];
                break;
            }
        }
    }
    
    NSMutableArray *wordArray = nil;
    NSString *strName = [NSString stringWithFormat:@"words_year%d", year];
    NSString *path = [[NSBundle mainBundle] pathForResource:strName ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    
    if (dict!=nil) {
        wordArray = [NSMutableArray array];
        for (int i=0; i<[numberArray count]; i++) {
            NSString *strKey = [numberArray objectAtIndex:i];
            NSDictionary *wordDic = [dict objectForKey:strKey];
            WordData *wd = [[WordData alloc]init];
            wd.WordNumber = [strKey integerValue];
            wd.EnglishWord = [wordDic objectForKey:@"ENG"];
            wd.KoreanWord = [wordDic objectForKey:@"KOR"];
            wd.Examples = [wordDic objectForKey:@"EX"];
            
            [wordArray addObject:wd];
        }
    }
    
    return wordArray;
}


@end
