//
//  WordDataManager.h
//  HohoWords
//
//  Created by lucid on 29/04/2019.
//  Copyright © 2019 lucid. All rights reserved.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

@interface WordDataManager : NSObject {
}

//+ (instancetype)instance;
//- (id) initManager;

+ (NSArray*)getWordArray:(int)year range:(NSRange)range count:(int)count;

@end

NS_ASSUME_NONNULL_END
