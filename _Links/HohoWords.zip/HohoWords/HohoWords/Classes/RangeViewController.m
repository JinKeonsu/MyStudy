//
//  RangeViewController.m
//  HohoWords
//
//  Created by lucid on 29/04/2019.
//  Copyright © 2019 lucid. All rights reserved.
//

#import "RangeViewController.h"
#import "TestViewController.h"


@interface RangeViewController ()
@property (weak, nonatomic) IBOutlet UITextField *txtFirstNum;
@property (weak, nonatomic) IBOutlet UITextField *txtEndNum;
@property (weak, nonatomic) IBOutlet UITextField *txtQuestionCount;

@end

@implementation RangeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - general funcs
- (BOOL)checkInputValues {
    if ([self.txtFirstNum.text length] > 0 && [self.txtEndNum.text length] > 0 && [self.txtQuestionCount.text length] > 0) {
        return YES;
    }
    else {
        return NO;
    }
}

#pragma mark - button event
- (IBAction)backButtonClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)nextButtonClicked:(id)sender {
    if ([self checkInputValues]) {
        UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        TestViewController *vc = [sb instantiateViewControllerWithIdentifier:@"TestVC"];
        [vc setNYear:1];
        [vc setStartNumber:[self.txtFirstNum.text intValue]];
        [vc setEndNumber:[self.txtEndNum.text intValue]];
        [vc setQuestionCount:[self.txtQuestionCount.text intValue]];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
