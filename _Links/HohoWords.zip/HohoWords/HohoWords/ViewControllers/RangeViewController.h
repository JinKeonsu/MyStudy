//
//  RangeViewController.h
//  HohoWords
//
//  Created by lucid on 29/04/2019.
//  Copyright © 2019 lucid. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RangeViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
