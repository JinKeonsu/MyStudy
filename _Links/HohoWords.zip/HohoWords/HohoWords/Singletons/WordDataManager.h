//
//  WordDataManager.h
//  HohoWords
//
//  Created by lucid on 29/04/2019.
//  Copyright © 2019 lucid. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface WordDataManager : NSObject {
    NSMutableArray *arrYear1;
    NSMutableArray *arrYear2;
    NSMutableArray *arrYear3;
}

+ (instancetype)instance;
- (id) initManager;

- (NSArray*)getWordArray:(int)year range:(int)num;

@end

NS_ASSUME_NONNULL_END
