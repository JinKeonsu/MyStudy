//
//  WordData.h
//  HohoWords
//
//  Created by lucid on 29/04/2019.
//  Copyright © 2019 lucid. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface WordData : NSObject

@property (nonatomic, assign)   int         WordNumber;     //word 번호
@property (nonatomic, retain)   NSString    *EnglishWord;   //영어 단어
@property (nonatomic, retain)   NSString    *KoreanWord;    //한글 뜻
//@property (nonatomic, retain)   NSString    *WordPOS;       //품사(Part of speech)

@end

NS_ASSUME_NONNULL_END
