//
//  WordDataManager.m
//  HohoWords
//
//  Created by lucid on 29/04/2019.
//  Copyright © 2019 lucid. All rights reserved.
//

#import "WordDataManager.h"
#import "WordData.h"

static __strong WordDataManager *g_wordDataManager = nil;


@implementation WordDataManager

+ (instancetype)instance {
    if (g_wordDataManager == nil) {
        g_wordDataManager = [[WordDataManager alloc] initManager];
    }
    return g_wordDataManager;
}

- (id)initManager {
    self = [super init];
    if (self)
    {
        arrYear1 = [NSMutableArray array];
        arrYear2 = [NSMutableArray array];
        arrYear3 = [NSMutableArray array];
        
        [self loadWordData];
    }
    
    return self;
}

- (void)loadWordData {
    NSDictionary *dict = [self JSONFromFile];
    
    NSArray *arr1 = [dict objectForKey:@"Y1"];
    for (NSDictionary *aWord in arr1) {
        WordData *wd = [[WordData alloc]init];
        wd.WordNumber = [[aWord objectForKey:@"NO"]intValue];
        wd.EnglishWord = [aWord objectForKey:@"ENG"];
        wd.KoreanWord = [aWord objectForKey:@"KOR"];
        
        [arrYear1 addObject:wd];
    }
    
    NSArray *arr2 = [dict objectForKey:@"Y2"];
    for (NSDictionary *aWord in arr2) {
        WordData *wd = [[WordData alloc]init];
        wd.WordNumber = [[aWord objectForKey:@"NO"]intValue];
        wd.EnglishWord = [aWord objectForKey:@"ENG"];
        wd.KoreanWord = [aWord objectForKey:@"KOR"];
        
        [arrYear2 addObject:wd];
    }
}

- (NSDictionary *)JSONFromFile {
    NSString *path = [[NSBundle mainBundle] pathForResource:@"words" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    return [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
}

- (NSArray*)getWordArray:(int)year range:(int)num {
    
    return nil;
}


@end
