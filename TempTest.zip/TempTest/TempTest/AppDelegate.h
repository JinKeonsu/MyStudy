//
//  AppDelegate.h
//  TempTest
//
//  Created by lucid on 29/03/2019.
//  Copyright © 2019 lucid. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

